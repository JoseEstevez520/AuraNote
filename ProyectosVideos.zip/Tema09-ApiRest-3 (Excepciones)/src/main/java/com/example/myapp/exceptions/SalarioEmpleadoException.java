package com.example.myapp.exceptions;

public class SalarioEmpleadoException extends RuntimeException {

    public SalarioEmpleadoException(double salarioEmpleado, double salarioMinimo) {
        super("Salario : " + salarioEmpleado + " incorrecto. Min:" + salarioMinimo);
    }
}
