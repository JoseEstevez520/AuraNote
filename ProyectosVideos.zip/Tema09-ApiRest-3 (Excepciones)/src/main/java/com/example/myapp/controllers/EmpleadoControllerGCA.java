package com.example.myapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.myapp.domain.Empleado;
import com.example.myapp.dto.EmpleadoListDto;
import com.example.myapp.dto.EmpleadoNuevoDto;
import com.example.myapp.services.DepartamentoService;
import com.example.myapp.services.EmpleadoService;
import com.example.myapp.utils.EmpleadoDtoConverter;

import jakarta.validation.Valid;

@RestController
public class EmpleadoControllerGCA {

    @Autowired
    public EmpleadoService empleadoService;

    @Autowired
    public DepartamentoService departamentoService;

    @Autowired
    public EmpleadoDtoConverter empleadoDtoConverter;

    @GetMapping("/empleados")
    public List<EmpleadoListDto> showList() {
        return empleadoDtoConverter.convertListEmpleadoToDto(empleadoService.obtenerTodos());                //cod 200
    }

    @GetMapping("/empleado/{id}")
    public ResponseEntity<?> showElement(@PathVariable Long id) {
        Empleado empleado = empleadoService.obtenerPorId(id);
        return ResponseEntity.ok(empleado);                   //cod 200
    }

    @PostMapping("/empleado/")
    public ResponseEntity<?>  showNewSubmit(@Valid @RequestBody EmpleadoNuevoDto empleadoForm) {
        //@Valid hara que se envie una respuesta 400 (BAD_REQUEST)
        Empleado empleado= empleadoDtoConverter.convertDtoNuevoToEmpleado (empleadoForm);   
        Empleado empleadoSaved = empleadoService.añadir(empleado);
        return ResponseEntity.status (HttpStatus.CREATED).body(empleadoSaved);  //cod.201
    }

    @PutMapping("/empleado/{id}")
    public ResponseEntity<?>  showEditSubmit(@PathVariable Long id, @Valid @RequestBody Empleado empleadoForm) {
        Empleado empleado = empleadoService.obtenerPorId(id);
        empleado = empleadoService.editar (empleadoForm);
        return ResponseEntity.status (HttpStatus.OK).body(empleado);     //cod 200
    }

    @DeleteMapping("/empleado/{id}")
    public  ResponseEntity<?>  showDelete(@PathVariable long id) {
        empleadoService.obtenerPorId(id);
        empleadoService.borrar(id);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();      //COD 204 
    }

    @GetMapping("/porDepto/{idDepto}")
    public ResponseEntity<?>  showbyDepto(@PathVariable Long idDepto) {
        return ResponseEntity.ok(empleadoService.obtenerPorDepartamentoId(idDepto));
    }

}
