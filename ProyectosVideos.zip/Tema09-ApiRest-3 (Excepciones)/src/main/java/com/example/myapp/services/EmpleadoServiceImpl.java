package com.example.myapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.myapp.domain.Empleado;
import com.example.myapp.exceptions.EmpleadoNotFoundException;
import com.example.myapp.exceptions.EmpleadosEmptyException;
import com.example.myapp.exceptions.SalarioEmpleadoException;
import com.example.myapp.repositories.EmpleadoRepository;

@Service
public class EmpleadoServiceImpl implements EmpleadoService {
    @Autowired
    EmpleadoRepository repositorio;

    private final Double MIN_SALAR = 18000D;

    public List<Empleado> obtenerTodos() {
        List<Empleado> listaEmpleados = repositorio.findAll(Sort.by(Sort.Direction.ASC, "nombre"));
        if (listaEmpleados.isEmpty()) throw new EmpleadosEmptyException();
        return listaEmpleados;
    }

    public Empleado obtenerPorId(long id) throws RuntimeException {
        return repositorio.findById(id).orElseThrow(() -> new EmpleadoNotFoundException(id));
    }

    public Empleado añadir(Empleado empleado) {
        if (empleado.getSalario() < MIN_SALAR) 
               throw new SalarioEmpleadoException(empleado.getSalario() ,MIN_SALAR);
        return repositorio.save(empleado);
    }

    public Empleado editar(Empleado empleado)  {
        obtenerPorId(empleado.getId()); 
        if (empleado.getSalario() < MIN_SALAR) 
        throw new SalarioEmpleadoException(empleado.getSalario() ,MIN_SALAR);
        return repositorio.save(empleado);
    }

    public void borrar(Long id) {
        obtenerPorId(id); 
        repositorio.deleteById(id);
    }

    public List<Empleado> obtenerPorDepartamentoId(Long idDepto) {
        return repositorio.findByDepartamentoId(idDepto);
    }
}
