package com.example.myapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.myapp.domain.Empleado;
import com.example.myapp.repositories.EmpleadoRepository;

@Service
public class EmpleadoServiceImpl implements EmpleadoService {
    @Autowired
    EmpleadoRepository repositorio;

    private final Double MIN_SALAR = 18000D;

    public List<Empleado> obtenerTodos() {
        return repositorio.findAll(Sort.by(Sort.Direction.ASC, "nombre"));
    }

    public Empleado obtenerPorId(long id) throws RuntimeException {
        return repositorio.findById(id).orElse(null);
        //.orElseThrow(() -> new RuntimeException("Empleado no encontrado"));
    }

    public Empleado añadir(Empleado empleado) {
        if (empleado.getSalario() < MIN_SALAR) return null;
            //throw new RuntimeException("Salario muy bajo");
        return repositorio.save(empleado);
    }

    public Empleado editar(Empleado empleado)  {
        Empleado buscaEmpleado = obtenerPorId(empleado.getId()); 
        if (buscaEmpleado==null) return null;
        if (empleado.getSalario() < MIN_SALAR) return null;
            //throw new RuntimeException("Salario muy bajo");
        return repositorio.save(empleado);
    }

    public void borrar(Long id) {
        //Empleado buscaEmpleado = obtenerPorId(id); 
        //if (buscaEmpleado==null) return;
        repositorio.deleteById(id);
    }

    public List<Empleado> obtenerPorDepartamentoId(Long idDepto) {
        return repositorio.findByDepartamentoId(idDepto);
    }
}
