package com.example.myapp.services;

import java.util.List;

import com.example.myapp.domain.Empleado;

public interface EmpleadoService {

    List<Empleado> obtenerTodos();

    Empleado obtenerPorId(long id);

    Empleado añadir(Empleado empleado);

    Empleado editar(Empleado empleado);

    void borrar(Long id);

    List<Empleado> obtenerPorDepartamentoId(Long idDepto);
}
