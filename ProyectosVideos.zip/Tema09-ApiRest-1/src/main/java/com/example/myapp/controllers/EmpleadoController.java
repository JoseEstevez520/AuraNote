package com.example.myapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.myapp.domain.Empleado;
import com.example.myapp.services.DepartamentoService;
import com.example.myapp.services.EmpleadoService;

import jakarta.validation.Valid;

@RestController
public class EmpleadoController {

    @Autowired
    public EmpleadoService empleadoService;

    @Autowired
    public DepartamentoService departamentoService;

    @GetMapping("/empleados")
    public List<Empleado> showList() {
        return empleadoService.obtenerTodos();                //cod 200
    }

    @GetMapping("/empleado/{id}")
    public ResponseEntity<?> showElement(@PathVariable Long id) {
        Empleado empleado = empleadoService.obtenerPorId(id);
        if (empleado != null) {
            //return empleadoService.obtenerPorId(id);
            //return ResponseEntity.status(HttpStatus.OK).body(empleado); 
            return ResponseEntity.ok(empleado);                   //cod 200

        } 
        else  {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build(); 
        }
    }

    @PostMapping("/empleado/")
    public ResponseEntity<?>  showNewSubmit(@Valid @RequestBody Empleado empleadoForm) {
        //@Valid hara que se envie una respuesta 400 (BAD_REQUEST)
         Empleado empleado=   empleadoService.añadir(empleadoForm);
        if (empleado!=null)
            return ResponseEntity.status (HttpStatus.CREATED).body(empleado);  //cod.201
        else
        //return ResponseEntity.status (HttpStatus.BAD_REQUEST).build();
        return ResponseEntity.badRequest().body("Error en alta de empleado");
    }

    @PutMapping("/empleado/{id}")
    public ResponseEntity<?>  showEditSubmit(@PathVariable Long id, @Valid @RequestBody Empleado empleadoForm) {
        Empleado empleado = empleadoService.obtenerPorId(id);
        if (empleado == null) 
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build(); 
        empleado = empleadoService.editar (empleadoForm);
        if (empleado!=null)
            return ResponseEntity.status (HttpStatus.OK).body(empleado);     //cod 200
        else
            return ResponseEntity.badRequest().body("Error en edición de empleado");
    }

    @DeleteMapping("/empleado/{id}")
    public  ResponseEntity<?>  showDelete(@PathVariable long id) {
        Empleado empleado = empleadoService.obtenerPorId(id);
        if (empleado == null) 
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build(); 
        empleadoService.borrar(id);
           return ResponseEntity.status(HttpStatus.NO_CONTENT).build();      //COD 204 
    }

    @GetMapping("/porDepto/{idDepto}")
    public ResponseEntity<?>  showbyDepto(@PathVariable Long idDepto) {
        return ResponseEntity.ok(empleadoService.obtenerPorDepartamentoId(idDepto));
    }

}
