package com.proyectosspring.myapp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.proyectosspring.myapp.domain.Departamento;

public interface DepartamentoRepository extends JpaRepository <Departamento, Long> {
}
