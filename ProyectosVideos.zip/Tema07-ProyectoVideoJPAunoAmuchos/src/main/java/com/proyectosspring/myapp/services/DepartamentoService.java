package com.proyectosspring.myapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyectosspring.myapp.domain.Departamento;
import com.proyectosspring.myapp.repositories.DepartamentoRepository;

@Service
public class DepartamentoService {

    @Autowired
    DepartamentoRepository departamentoRepository;
    public List<Departamento> obtenerTodos() {
        return departamentoRepository.findAll();
    }

    public Departamento obtenerPorId(Long id) {
        //return departamentoRepository.findById(id).orElse(null);
        return departamentoRepository.findById(id).orElseThrow(()->new RuntimeException("Departamento no encontrado"));
    }

    public Departamento añadir(Departamento departamento) {
        return departamentoRepository.save(departamento);
    }

    public Departamento actualizar(Departamento departamento) {
        departamentoRepository.save(departamento);
        return departamento;
    }

    public void eliminarPorId(Long id) {
          departamentoRepository.deleteById(id);     
    }

    public void eliminar(Departamento departamento) {
        departamentoRepository.delete(departamento);
    }

}
