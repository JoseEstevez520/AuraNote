package com.proyectosspring.myapp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.proyectosspring.myapp.domain.Departamento;
import com.proyectosspring.myapp.services.DepartamentoService;
import com.proyectosspring.myapp.services.EmpleadoService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/depto")
public class DepartamentoController {

    @Autowired
    DepartamentoService departamentoService;

    @Autowired
    EmpleadoService empleadoService;

    @GetMapping({ "/list", "/" })
    public String getList(Model model) {
        model.addAttribute("listaDepartamentos", departamentoService.obtenerTodos());
        return "departamento/listView";
    }

    
    @GetMapping("/add")
    public String getNew(@RequestParam(required = false) Integer err, Model model) {
        model.addAttribute("departamentoForm", new Departamento());
        return "departamento/newFormView";
    }

    @PostMapping("/add/submit")
    public String getNewSubmit(@Valid Departamento departamentoForm, BindingResult bindingResult) {
            departamentoService.añadir(departamentoForm);
        return "redirect:/depto/list";
    }

    @GetMapping("/edit/{id}")
    public String getEdit(@PathVariable Long id, Model model) {
        Departamento departamento = departamentoService.obtenerPorId(id);
        model.addAttribute("departamentoForm", departamento);
        return "departamento/editFormView";
    }

    @PostMapping("/edit/submit")
    public String getEditSubmit(@Valid Departamento departamentoForm, BindingResult bindingResult) {
        departamentoService.actualizar(departamentoForm);
        return "redirect:/depto/list";
    }

    @GetMapping("/borrar/{id}")
    public String showDelete(@PathVariable long id) {
        departamentoService.eliminarPorId(id);
        return "redirect:/depto/list";
    }

    @GetMapping("/empleados/{id}")
    public String showEmpl(@PathVariable long id, Model model) {
       Departamento departamento = departamentoService.obtenerPorId(id);
       model.addAttribute("listaEmpleados", departamento.getEmpleados());
       model.addAttribute("tituloListado", "Empleados por departamento");
       return "empleado/listView";
    }

}
