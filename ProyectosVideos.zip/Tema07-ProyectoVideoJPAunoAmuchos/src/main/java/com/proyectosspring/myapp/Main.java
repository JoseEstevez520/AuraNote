package com.proyectosspring.myapp;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.proyectosspring.myapp.domain.Departamento;
import com.proyectosspring.myapp.domain.Empleado;
import com.proyectosspring.myapp.services.DepartamentoService;
import com.proyectosspring.myapp.services.EmpleadoService;

@SpringBootApplication
public class Main {

	public static void main(String[] args) {
		SpringApplication.run(Main.class, args);
	}

	@Bean
	CommandLineRunner initData(EmpleadoService empleadoService, DepartamentoService departamentoService) {
		return args -> {
			Departamento depto1= departamentoService.añadir(new Departamento(null, "Informática", null));
			Departamento depto2= departamentoService.añadir(new Departamento (null, "RRHH", null));
			
			empleadoService.añadir(new Empleado(null, "López Pérez, José", 25000d, null, depto1));
			empleadoService.añadir(new Empleado(null, "Vázquez, Ana", 45000d, null, depto2));
		};
	}
}
