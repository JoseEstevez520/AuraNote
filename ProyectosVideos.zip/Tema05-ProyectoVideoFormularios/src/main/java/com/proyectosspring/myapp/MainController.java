package com.proyectosspring.myapp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.validation.Valid;

@Controller
public class MainController {
    List<String> provincias = new ArrayList<>(Arrays.asList("A Coruña", "Lugo", "Ourense", "Pontevedra"));

    @GetMapping("/")
    public String showForm(Model model) {
        model.addAttribute("formInfo", new FormInfo());
        model.addAttribute("provincias", provincias);
        return "formView";
    }

    @PostMapping("/formsubmit")
    public String submitForm(@Valid @ModelAttribute FormInfo formInfo, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            return "redirect:/";
        }
        formInfo.setNombre(formInfo.getNombre().toUpperCase());
        return "formResult";
    }

}
