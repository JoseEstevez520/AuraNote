package com.proyectosspring.myapp;

public enum EstadoCivil {
    SOLTERO, CASADO, OTROS
}
