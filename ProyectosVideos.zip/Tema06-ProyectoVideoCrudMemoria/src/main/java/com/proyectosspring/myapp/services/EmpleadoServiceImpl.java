package com.proyectosspring.myapp.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.proyectosspring.myapp.domain.Empleado;
import com.proyectosspring.myapp.dto.EmpleadoDto;

@Service
public class EmpleadoServiceImpl implements EmpleadoService {

    List<Empleado> empleadoRepository = new ArrayList<>();
    private final Double SALARIO_MIN = 1000d;
    private final Double SALARIO_MAX = 100000d;

    public List<Empleado> obtenerTodos() {
        return empleadoRepository;
    }

    public List<Empleado> obtenerPorSalarioMayor(Double salario) {
        List<Empleado> empleados = new ArrayList<>();
        for (Empleado empleado : empleadoRepository) {
            if (empleado.getSalario() > salario) {
                empleados.add(empleado);
            }
        }
        return empleados;
    }

    public Empleado obtenerPorId(Long id) {
        for (Empleado empleado : empleadoRepository) {
            if (empleado.getId().equals(id)) {
                return empleado;
            }
        }
        throw new RuntimeException("Empleado no encontrado");
    }

    public Empleado añadir(Empleado empleado) {
        if (empleado.getSalario() < SALARIO_MIN || empleado.getSalario() > SALARIO_MAX) {
            throw new RuntimeException("Salario fuera de rango");
        }
        empleado.setFechaRegistro(LocalDate.now());
        empleadoRepository.add(empleado);
        return empleado;
    }

    public Empleado actualizar(Empleado empleado) {
        if (empleado.getSalario() < SALARIO_MIN || empleado.getSalario() > SALARIO_MAX) {
            throw new RuntimeException("Salario fuera de rango");
        }
        int pos = empleadoRepository.indexOf(empleado);
        if (pos == -1)
            return null;
        empleadoRepository.set(pos, empleado);
        return empleado;
    }

    public Empleado actualizarSalario(EmpleadoDto empleadoDto) {
        if (empleadoDto.getNuevoSalario() < SALARIO_MIN || empleadoDto.getNuevoSalario() > SALARIO_MAX) {
            throw new RuntimeException("Salario fuera de rango");
        }
        Empleado empleado = obtenerPorId(empleadoDto.getId());
        if (empleado != null) {
            empleado.setSalario(empleadoDto.getNuevoSalario());
        }
        return actualizar(empleado);

    }

    public void eliminarPorId(Long id) {
        Empleado empleado = obtenerPorId(id);
        if (empleado != null) {
            empleadoRepository.remove(empleado);
        }
    }

    public void eliminar(Empleado empleado) {
        empleadoRepository.remove(empleado);
    }

    public EmpleadoDto convertEmpleadoToDto(Empleado empleado) {
        return new EmpleadoDto(empleado.getId(), empleado.getSalario());
    }

    // //Se podría añadir un método para validar el rango de salario y no duplicar
    // código
    // private boolean validarSalario(Double salario) {
    // if (salario < SALARIO_MIN || salario > SALARIO_MAX) return false;
    // else return true;
    // }
    //
    // y llamar a este método en los métodos añadir, actualizar y actualizarSalario.
    //
    // if (validarSalario(empleadoDto.getNuevoSalario())) {
    // throw new RuntimeException("Salario fuera de rango");
    // }
}
