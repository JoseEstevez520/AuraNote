package com.proyectosspring.myapp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.proyectosspring.myapp.domain.Empleado;
import com.proyectosspring.myapp.dto.EmpleadoDto;
import com.proyectosspring.myapp.services.EmpleadoService;

import jakarta.validation.Valid;

@Controller
public class EmpleadoController {

    @Autowired
    EmpleadoService empleadoService;

    private String txtErr;

    @GetMapping({ "/list", "/" })
    public String getList(@RequestParam(required = false) Integer err, Model model) {
        if (err != null) {
            model.addAttribute("txtError", txtErr);
        }
        model.addAttribute("listaEmpleados", empleadoService.obtenerTodos());
        return "listView";
    }

    @GetMapping("/listone/{id}")
    public String getOne(@PathVariable Long id, Model model) {
        try {
            model.addAttribute("empleado", empleadoService.obtenerPorId(id));
        } catch (RuntimeException e) {
            txtErr = e.getMessage();
            return "redirect:/list?err=1";
        }
        return "listOneView";
    }

    @GetMapping("/add")
    public String getNew(@RequestParam(required = false) Integer err, Model model) {
        if (err != null) {
            model.addAttribute("txtError", "Error en los datos");
        }
        model.addAttribute("empleadoForm", new Empleado());
        return "newFormView";
    }

    @PostMapping("/add/submit")
    public String getNewSubmit(@Valid Empleado empleadoForm, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            txtErr = "Parámetros incorrectos al añadir empleado";
            return "redirect:/list?err=1";
            // return "redirect:/add?err=1";
        }
        try {
            empleadoService.añadir(empleadoForm);
        } catch (RuntimeException e) {
            txtErr = e.getMessage();
            return "redirect:/list?err=1";
        }
        return "redirect:/list";
    }

    @GetMapping("/edit/{id}")
    public String getEdit(@PathVariable Long id, Model model) {
        Empleado empleado = empleadoService.obtenerPorId(id);
        model.addAttribute("empleadoForm", empleado);
        return "editFormView";
    }

    @PostMapping("/edit/submit")
    public String getEditSubmit(@Valid Empleado empleadoForm, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            txtErr = "Parámetros incorrectos al editar empleado";
            return "redirect:/list?err=1";
        }
        try {
            empleadoService.actualizar(empleadoForm);
        } catch (RuntimeException e) {
            txtErr = e.getMessage();
            return "redirect:/list?err=1";
        }
        return "redirect:/list";
    }

    @GetMapping("/editSalar/{id}")
    public String getEditSalar(@PathVariable Long id, Model model) {
        Empleado empleado = empleadoService.obtenerPorId(id);
        EmpleadoDto empleadoDto = empleadoService.convertEmpleadoToDto(empleado);
        model.addAttribute("empleadoDtoForm", empleadoDto);
        return "editSalarFormView";
    }

    @PostMapping("/editSalar/submit")
    public String getEditSalarSubmit(EmpleadoDto empleadoDto) {
        try {
            empleadoService.actualizarSalario(empleadoDto);
        } catch (RuntimeException e) {
            txtErr = e.getMessage();
            return "redirect:/list?err=1";
        }
        return "redirect:/list";
    }

    @GetMapping("/borrar/{id}")
    public String showDelete(@PathVariable long id) {
        try {
            empleadoService.obtenerPorId(id);
        } catch (RuntimeException e) {
            txtErr = e.getMessage();
            return "redirect:/list?err=1";
        }
        empleadoService.eliminarPorId(id);
        return "redirect:/list";
    }
}
