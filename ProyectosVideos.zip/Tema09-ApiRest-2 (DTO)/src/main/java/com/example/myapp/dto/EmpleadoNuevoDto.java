package com.example.myapp.dto;

import com.example.myapp.domain.Genero;

public record EmpleadoNuevoDto 
(String nombre, String email, Double salario, Genero genero, Long departamentoId)
{
    
}
