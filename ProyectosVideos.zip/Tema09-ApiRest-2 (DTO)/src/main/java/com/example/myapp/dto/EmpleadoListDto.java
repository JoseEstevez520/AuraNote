package com.example.myapp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class EmpleadoListDto {
    private Long id;
    private String nombre;
    private String email;
    private String departamentoNombre;
}
