package com.example.myapp.utils;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.stereotype.Component;

import com.example.myapp.domain.Empleado;
import com.example.myapp.dto.EmpleadoListDto;
import com.example.myapp.dto.EmpleadoNuevoDto;
import com.example.myapp.services.DepartamentoService;

@Component
public class EmpleadoDtoConverter {

    @Autowired
    DepartamentoService departamentoService;

    @Autowired
    ModelMapper modelMapper;

    public List<EmpleadoListDto> convertListEmpleadoToDto (List<Empleado> listaEmpleados){
        // List<EmpleadoListDto> listaEmpleadoDto = new ArrayList<>();
        // for (Empleado empleado : listaEmpleados){
        //     listaEmpleadoDto.add (this.convertEmpleadoToDto(empleado));
        // }
        // return listaEmpleadoDto;
        return listaEmpleados.stream().
              map(this::convertEmpleadoToDto).
              collect(Collectors.toList());

    }

    public EmpleadoListDto convertEmpleadoToDto (Empleado empleado) {
        //   return new EmpleadoListDto (empleado.getId(), empleado.getNombre(),
        //      empleado.getEmail(), empleado.getDepartamento().getNombre());
        return modelMapper.map(empleado,EmpleadoListDto.class);
    }

    public Empleado convertDtoNuevoToEmpleado (EmpleadoNuevoDto empleadoNuevoDto){
         return new Empleado (null,
           empleadoNuevoDto.nombre(),
           empleadoNuevoDto.email(),
           empleadoNuevoDto.salario(),
           true,
           empleadoNuevoDto.genero(),
           departamentoService.obtenerPorId(empleadoNuevoDto.departamentoId()));
    }  
}
