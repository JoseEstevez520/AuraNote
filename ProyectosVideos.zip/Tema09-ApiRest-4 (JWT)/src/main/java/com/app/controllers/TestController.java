package com.app.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/test")
public class TestController {
  
  @GetMapping("/all")
  public String showContentForAll() {
    return "Contenido público";
  }

  @GetMapping("/user")
  public String showContentForUsers() {
    return "Contenido para usuarios";
  }

  @GetMapping("/manager")
  public String showContentForManager() {
    return "Contenido para usuarios de tipo Manager";
  }

  @GetMapping("/admin")
  public String showContentForAdmins() {
    return "Contenido para administradores";
  }
}
