package com.app.modelo;

public enum Rol {
  USER,
  MANAGER,
  ADMIN
}
