package com.example.myapp.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.myapp.domain.Empleado;
import com.example.myapp.domain.Genero;

public interface EmpleadoRepository extends JpaRepository<Empleado, Long> {

        // Métodos derivado por nombre
        List<Empleado> findByNombre(String nombre);

        List<Empleado> findByNombreContainingIgnoreCase(String nombre);

        List<Empleado> findByGenero(Genero genero);

        List<Empleado> findBySalarioGreaterThanEqualOrderBySalario(double salario);

        List<Empleado> findByNombreOrderByNombreAsc(String nombre);


        // Método a medida con JPQL:
        @Query("select e from Empleado e " +
                        "where e.salario > (select avg (e2.salario) from Empleado e2)")
        List<Empleado> queryBySalarioOverAverage();
}
