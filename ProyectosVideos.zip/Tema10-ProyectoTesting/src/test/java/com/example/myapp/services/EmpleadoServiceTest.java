package com.example.myapp.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.myapp.domain.Empleado;
import com.example.myapp.repositories.EmpleadoRepository;

@SpringBootTest
@TestInstance(Lifecycle.PER_CLASS)
public class EmpleadoServiceTest {

    @InjectMocks
    EmpleadoServiceImpl empleadoService;

    @Mock
    EmpleadoRepository empleadoRepository;

    ArrayList<Empleado> mockList;
    Empleado empleadoSinId, empleadoConId;

    @BeforeAll
    public void init() {
        mockList = new ArrayList<>();
        mockList.add(new Empleado(1L, "test1", "test1@mail.com", 30000d, true));
        mockList.add(new Empleado(2L, "test2", "test2@mail.com", 40000d, false));
        mockList.add(new Empleado(3L, "test3", "test3@mail.com", 45000d, true));

        empleadoSinId = new Empleado(null, "Eva", "eva@mail.com", 35000d, true);
        empleadoConId = new Empleado(5L, "Eva", "eva@mail.com", 35000d, true);
    }

    @Test
    // el mock de findAll devuelve 3 filas, pero el método obtenerTodos solo se
    // queda con dos. No toma a "test2" porque no está en activo.
    public void obtenerTodosTest() {
        when(empleadoRepository.findAll()).thenReturn(mockList);
        List<Empleado> empList = empleadoService.obtenerTodos();
        assertEquals(2, empList.size());
        verify(empleadoRepository, times(1)).findAll();
    }

    @Test
    public void obtenerPorIdTest() {
        when(empleadoRepository.findById(1L)).thenReturn(Optional.of(mockList.get(0)));
        Empleado empleado = empleadoService.obtenerPorId(1L);
        assertEquals("test1", empleado.getNombre());
        assertEquals("test1@mail.com", empleado.getEmail());
        assertEquals(30000, empleado.getSalario());
    }

    @Test
    public void añadirTest_ok() {
        when(empleadoRepository.save(empleadoSinId)).thenReturn(empleadoConId);
        Empleado insertado = empleadoService.añadir(empleadoSinId);
        assertEquals(5L, insertado.getId());
        assertEquals("Eva", insertado.getNombre());
        verify(empleadoRepository, times(1)).save(empleadoSinId);
    }

    @Test
    public void añadirTest_ko() {
        Empleado empleadoErr = new Empleado(null, "err", "err@mail.com", 100d, true);
        // when(empleadoRepository.save(empleadoNew)).thenReturn(empleadoNew);
        assertThrows(RuntimeException.class, () -> {
            empleadoService.añadir(empleadoErr);
        });
        verify(empleadoRepository, times(0)).save(empleadoErr);
    }

    @Test
    public void borrarTest_ok() {
        when(empleadoRepository.findById(1L))
                .thenReturn(Optional.of(mockList.get(0)));
        empleadoService.borrar(1L);
        verify(empleadoRepository, times(1)).findById(1L);
        verify(empleadoRepository, times(1)).deleteById(1L);
    }

    @Test
    public void borrarTest_notFound() {
        when(empleadoRepository.findById(999L)).thenReturn(Optional.empty());
        // when(empleadoRepository.findById(999L)).thenReturn(Optional.ofNullable(null));
        assertThrows(RuntimeException.class, () -> {
            empleadoService.borrar(999L);
        });
        verify(empleadoRepository, times(1)).findById(999L);
        verify(empleadoRepository, times(0)).deleteById(999L);
    }
}
