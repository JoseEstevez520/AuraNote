package com.proyectosspring.myapp.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.proyectosspring.myapp.domain.Empleado;

public interface EmpleadoRepository extends JpaRepository <Empleado, Long> {
    List<Empleado> findBySalario (Double salario);
    List<Empleado> findBySalarioGreaterThanEqual (Double salario);
    List<Empleado> findBySalarioAndNombre (Double salario, String nombre);

    @Query ("select e from Empleado e where e.id=(select max(e2.id) from Empleado e2)")
    Empleado obtenerMaxIdEmpleado();
}
