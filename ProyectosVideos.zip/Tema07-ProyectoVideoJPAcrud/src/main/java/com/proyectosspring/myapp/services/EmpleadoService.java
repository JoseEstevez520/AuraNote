package com.proyectosspring.myapp.services;

import java.util.List;

import com.proyectosspring.myapp.domain.Empleado;
import com.proyectosspring.myapp.dto.EmpleadoDto;

public interface EmpleadoService {
    List<Empleado> obtenerTodos();

    List<Empleado> obtenerPorSalarioMayor(Double salario);

    Empleado obtenerPorId(Long id);

    Empleado añadir(Empleado empleado);

    Empleado actualizar(Empleado empleado);

    Empleado actualizarSalario(EmpleadoDto empleadoDto);

    void eliminarPorId(Long id);

    void eliminar(Empleado empleado);

    public Empleado obtenerMaxIdEmpleado();

    EmpleadoDto convertEmpleadoToDto(Empleado empleado);
}
