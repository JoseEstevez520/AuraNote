package com.proyectosspring.myapp.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proyectosspring.myapp.domain.Empleado;
import com.proyectosspring.myapp.dto.EmpleadoDto;
import com.proyectosspring.myapp.repositories.EmpleadoRepository;

@Service
public class EmpleadoServiceImplBd implements EmpleadoService {

    @Autowired
    EmpleadoRepository empleadoRepository;

    private final Double SALARIO_MIN = 1000d;
    private final Double SALARIO_MAX = 100000d;

    public List<Empleado> obtenerTodos() {
        return empleadoRepository.findAll();
    }

    public List<Empleado> obtenerPorSalarioMayor(Double salario) {
        return empleadoRepository.findBySalarioGreaterThanEqual(salario);
        
    }

    public Empleado obtenerMaxIdEmpleado() {
        return empleadoRepository.obtenerMaxIdEmpleado();
    }
    public Empleado obtenerPorId(Long id) {
        //return empleadoRepository.findById(id).orElse(null);
        return empleadoRepository.findById(id).orElseThrow(()->new RuntimeException("Empleado no encontrado"));
    }

    public Empleado añadir(Empleado empleado) {
        if (empleado.getSalario() < SALARIO_MIN || empleado.getSalario() > SALARIO_MAX) {
            throw new RuntimeException("Salario fuera de rango");
        }
        empleado.setFechaRegistro(LocalDate.now());
        return empleadoRepository.save(empleado);
    }

    public Empleado actualizar(Empleado empleado) {
        if (empleado.getSalario() < SALARIO_MIN || empleado.getSalario() > SALARIO_MAX) {
            throw new RuntimeException("Salario fuera de rango");
        }
        //this.obtenerPorId(empleado.getId());
        empleadoRepository.save(empleado);
        return empleado;
    }

    public Empleado actualizarSalario(EmpleadoDto empleadoDto) {
        if (empleadoDto.getNuevoSalario() < SALARIO_MIN || empleadoDto.getNuevoSalario() > SALARIO_MAX) {
            throw new RuntimeException("Salario fuera de rango");
        }
        Empleado empleado = obtenerPorId(empleadoDto.getId());
        if (empleado != null) {
            empleado.setSalario(empleadoDto.getNuevoSalario());
        }
        return actualizar(empleado);

    }

    public void eliminarPorId(Long id) {
          empleadoRepository.deleteById(id);     
    }

    public void eliminar(Empleado empleado) {
        empleadoRepository.delete(empleado);
    }

    public EmpleadoDto convertEmpleadoToDto(Empleado empleado) {
        return new EmpleadoDto(empleado.getId(), empleado.getSalario());
    }

    // //Se podría añadir un método para validar el rango de salario y no duplicar
    // código
    // private boolean validarSalario(Double salario) {
    // if (salario < SALARIO_MIN || salario > SALARIO_MAX) return false;
    // else return true;
    // }
    //
    // y llamar a este método en los métodos añadir, actualizar y actualizarSalario.
    //
    // if (validarSalario(empleadoDto.getNuevoSalario())) {
    // throw new RuntimeException("Salario fuera de rango");
    // }
}
