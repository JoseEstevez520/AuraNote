package com.example.myapp;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.myapp.domain.Empleado;
import com.example.myapp.domain.Genero;
import com.example.myapp.domain.Proyecto;
import com.example.myapp.services.EmpleadoService;
import com.example.myapp.services.ProyectoService;

@SpringBootApplication
public class Main {

	public static void main(String[] args) {
		SpringApplication.run(Main.class, args);
	}

	@Bean
	CommandLineRunner initData(EmpleadoService empleadoService, ProyectoService proyectoService) {
		return args -> {

			proyectoService.añadir(new Proyecto(null, "Nueva normativa UE"));
			proyectoService.añadir(new Proyecto(null, "Captación nuevos clientes"));

			empleadoService.añadir(
					new Empleado(null, "López Pérez, José", "jlp@gmail.com", 18000d, true, Genero.MASCULINO));
			empleadoService.añadir(new Empleado(null, "García Martínez, Ana", "ana_garcia@gmail.com", 20000d, false,
					Genero.FEMENINO));

		};
	}

}
