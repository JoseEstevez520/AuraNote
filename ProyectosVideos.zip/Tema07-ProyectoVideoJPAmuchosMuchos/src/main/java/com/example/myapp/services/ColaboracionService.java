package com.example.myapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.example.myapp.domain.Colaboracion;
import com.example.myapp.repositories.ColaboracionRepository;

@Service
@Primary
public class ColaboracionService {

    @Autowired
    ColaboracionRepository colaboracionRepository;

    public Colaboracion añadir(Colaboracion colaboracion) {
        return colaboracionRepository.save(colaboracion);
    }

    // public List<Colaboracion> obtenerTodos() {
    // return colaboracionRepository.findAll();
    // }

    public Colaboracion obtenerPorId(long id) {
        return colaboracionRepository.findById(id).orElse(null);
    }

    public void borrar(Long id) {
        colaboracionRepository.deleteById(id);
    }

    public List<Colaboracion> obtenerPorEmpleadoId(Long empleadoId) {
        return colaboracionRepository.findByEmpleadoId(empleadoId);
    }

    public List<Colaboracion> obtenerPorProyectoId(Long proyectoId) {
        return colaboracionRepository.findByProyectoId(proyectoId);
    }

}
