package com.example.myapp.services;

import java.util.List;

import com.example.myapp.domain.Empleado;

public interface EmpleadoService {
    List<Empleado> obtenerTodos();

    Empleado obtenerPorId(Long id);

    Empleado añadir(Empleado empleado);

    Empleado editar(Empleado empleado);



    void eliminarPorId(Long id);

    void eliminar(Empleado empleado);

}
