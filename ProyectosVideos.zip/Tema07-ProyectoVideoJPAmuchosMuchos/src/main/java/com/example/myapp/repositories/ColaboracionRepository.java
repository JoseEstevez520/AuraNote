package com.example.myapp.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.myapp.domain.Colaboracion;

public interface ColaboracionRepository extends JpaRepository<Colaboracion, Long> {
    List<Colaboracion> findByEmpleadoId (Long idEmpleado);
    List<Colaboracion> findByProyectoId (Long idProyecto);
}
