package com.example.myapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.myapp.domain.Empleado;

import com.example.myapp.repositories.EmpleadoRepository;

@Service
public class EmpleadoServiceImplBd implements EmpleadoService {

    @Autowired
    EmpleadoRepository empleadoRepository;

    private final Double SALARIO_MIN = 1000d;
    private final Double SALARIO_MAX = 100000d;

    public List<Empleado> obtenerTodos() {
        return empleadoRepository.findAll();
    }

    public Empleado obtenerPorId(Long id) {
        // return empleadoRepository.findById(id).orElse(null);
        return empleadoRepository.findById(id).orElseThrow(() -> new RuntimeException("Empleado no encontrado"));
    }

    public Empleado añadir(Empleado empleado) {
        if (empleado.getSalario() < SALARIO_MIN || empleado.getSalario() > SALARIO_MAX) {
            throw new RuntimeException("Salario fuera de rango");
        }
        return empleadoRepository.save(empleado);
    }

    public Empleado editar(Empleado empleado) {
        if (empleado.getSalario() < SALARIO_MIN || empleado.getSalario() > SALARIO_MAX) {
            throw new RuntimeException("Salario fuera de rango");
        }
        // this.obtenerPorId(empleado.getId());
        empleadoRepository.save(empleado);
        return empleado;
    }


    public void eliminarPorId(Long id) {
        empleadoRepository.deleteById(id);
    }

    public void eliminar(Empleado empleado) {
        empleadoRepository.delete(empleado);
    }

}